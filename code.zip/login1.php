
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  
  <title>Admin | Voting System</title>
  <?php include('./header.php'); ?>

<?php 


include('db_connect.php');
extract($_POST);
if(isset($save))
{
//check whether user already exists or not
$sql=mysqli_query($conn,"select * from users where name='$name'");

$r=mysqli_num_rows($sql);
if($r==true)
{
$err= "<font color='red'>This user name already exists,register another one</font>";
}else{

$query="insert into user values('','$name','$password','$type')";
mysqli_query($conn,$query);
$err="<font color='blue'>Registration successfull !!</font>";
}



}


 ?>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    /*background: #007bff;*/
	}
	main#main{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-right{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:white;
		display: flex;
		align-items: center;
	}
	#login-left{
		position: absolute;
		left:0;
		width:60%;
		height: calc(100%);
		background:#00000061;
		display: flex;
		align-items: center;
	}
	#login-right .card{
		margin: auto
	}
	.logo {
    margin: auto;
    font-size: 8rem;
    background: white;
    padding: .5em 0.8em;
    border-radius: 50% 50%;
    color: #000000b3;
}
</style>

<body>


  <main id="main" class=" alert-info">

  	<div class="row">
	<div class="col-lg-12">
			
	</div>

	</div>
	<br>

  		<div id="login-left">
  			<div class="logo">
  				<i class="fa fa-poll-h"></i>
  			</div>
  		</div>
  		<div id="login-right">
  			<div class="card col-md-8">
  				<div class="card-body">
  					<form method="post" enctype="multipart/form-data">
  						<div class="form-group">
  							<h2>Registation form</h2>
  							<Td colspan="2"><?php echo @$err;?></Td>
  							<input type="hidden" name="type"  value="2" ">
  							<div class="form-group">
  							<label for="username" class="control-label">Name</label>
  							<input type="text"  name="name" class="form-control" required>
  							</div>

  							<div class="form-group">
  							<label for="username" class="control-label">Username</label>
  							<input type="text" name="username"   class="form-control" required>
  							</div>



  							</div>
  							<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" name="password"  class="form-control" required>
  							</div>


  						<div class="form-group">
						<label for="type">User Type</label>
						<select name="type" id="type" class="custom-select">
							
								<option value="2" <?php echo isset($meta['type']) && $meta['type'] == 2 ? 'selected': '' ?>>User</option>
						</select>


  						</div>
  						<center><input type="submit" name="save" class="btn-sm btn-block btn-wave col-md-4 btn-primary" value="Register"> </center>


  					</form>

  					<center>

  						<a href="login.php"> 				

  						<button class="btn-sm btn-block btn-wave col-md-9 btn-primary" style="margin: 20px" id="new_user">alredy have an account</button>
  					</a> 



  					</center>
  				</div>
  			</div>
  		</div>
   

  </main>

</body>
<!--script>

	
	$('#Register-form').submit(function(e){
		e.preventDefault();
		start_load()
		$.ajax({
			url:'ajax.php?action=save_user',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp ==1){
					alert_toast("Data successfully saved",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}
			}
		})
	})
</script-->	

<script type="text/javascript">
	
$('#new_user').click(function(){
	uni_modal('New User','manage_user.php')

</script>
</html>